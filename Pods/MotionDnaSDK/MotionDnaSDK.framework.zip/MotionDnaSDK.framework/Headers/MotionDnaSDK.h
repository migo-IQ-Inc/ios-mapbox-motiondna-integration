//
//  MotionDnaApplication.h
//  MotionDnaApplication
//
//  Created by Navisens, Inc on 8/19/15.
//  Copyright (c) 2015 Navisens, Inc. All rights reserved.
//

#ifndef MotionDnaSDK_RELEASE_h
#define MotionDnaSDK_RELEASE_h

#import "MotionDna.h"
#import "MotionDnaSDK_shared.h"

@interface MotionDnaSDK(RELEASEA)

@end


#endif /* MotionDnaSDK_h */
